﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Web;

namespace ContactInfoMaintain.DBConnection
{
    public class DBHelper
    {
        public static string pathToDB =@"D:/database.db";
        public DBHelper()
        {

        }
        SQLiteConnection sqlite_conn;
        public static SQLiteConnection CreateConnection()
        {
            SQLiteConnection sqlite_conn;
            sqlite_conn = new SQLiteConnection("Data Source="+pathToDB+"; Version = 3; New = True; Compress = True; ");
            try
            {
                sqlite_conn.Open();
            }
            catch (Exception ex)
            {
                sqlite_conn = null;
            }
            return sqlite_conn;
        }

       public static void CreateTable(SQLiteConnection conn)
        {
            SQLiteCommand sqlite_cmd;
            string Createsql = "CREATE TABLE ContactInfoMaintain(FirstName VARCHAR(20), LastName VARCHAR(20),Email VARCHAR(20), PhoneNumber VARCHAR(20),Status VARCHAR(20))";
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = Createsql;
            sqlite_cmd.ExecuteNonQuery();
        }
        public static bool CheckTableInDatabase(SQLiteConnection conn)
        {
            bool tableExists = false;
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = $"SELECT count(*) FROM sqlite_master WHERE type='table' AND name='ContactInfoMaintain';";
            object result = sqlite_cmd.ExecuteScalar();
            int resultCount = Convert.ToInt32(result);
            if (resultCount > 0)
            {
                tableExists = true;
            }
            return tableExists;
        }
        public static void InsertData(SQLiteConnection conn,string insertQuery)
        {
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = insertQuery;
            sqlite_cmd.ExecuteNonQuery();
            
        }
       public static void UpdateData(SQLiteConnection conn,string query)
        {
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = query;
            sqlite_cmd.ExecuteNonQuery();
        }

      public static void DeleteData(SQLiteConnection conn, string PhoneNumber)
        {
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "DELETE FROM ContactInfoMaintain WHERE PhoneNumber = '"+ PhoneNumber + "'; ";
            sqlite_cmd.ExecuteNonQuery();

        }
      public static void ChangeStatusOfData(SQLiteConnection conn, string PhoneNumber)
        {
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "UPDATE ContactInfoMaintain SET Status = 'Active',Status = CASE WHEN Status = 'Active' THEN 'Inactive' ELSE Status END WHERE PhoneNumber = '"+ PhoneNumber + "'; ";
            sqlite_cmd.ExecuteNonQuery();

        }
      public static SQLiteDataReader ReadData(SQLiteConnection conn)
        {
            SQLiteDataReader sqlite_datareader;
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();
            sqlite_cmd.CommandText = "SELECT * FROM ContactInfoMaintain";

            sqlite_datareader = sqlite_cmd.ExecuteReader();
            return sqlite_datareader;
        }
       public static void CloseConnection(SQLiteConnection conn)
        {
            conn.Close();
        }
    }
}