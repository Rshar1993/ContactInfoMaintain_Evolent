﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ContactInfoMaintain.Models
{
    public class ContactDetails
    {
        public List<ContactInfo> InfoDetails { get; set; }

    }
    public class ContactInfo
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
       
        [EmailAddress(ErrorMessage = "Invalid Email Address.")]
        public string Email { get; set; }
        [Phone(ErrorMessage = "Invalid Email Address.")]
        public string PhoneNumber { get; set; }
        public string Status { get; set; }
    }

    public class PhoneNumberInfo
    {
        public string OldNumber { get; set; }
        public string NewNumber { get; set; }

    }

}