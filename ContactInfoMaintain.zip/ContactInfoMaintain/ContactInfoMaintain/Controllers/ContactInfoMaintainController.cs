﻿using ContactInfoMaintain.Models;
using ContactInfoMaintain.DBConnection;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SQLite;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Xml;
using System.Text.RegularExpressions;
using ContactInfoMaintain.Helper;

namespace ContactInfoMaintain.Controllers
{
    public class ContactInfoMaintainController : ApiController
    {
        static readonly object _object = new object();
        static string _sessionToken = "";
        static string SessionToken
        {
            get
            {
                if (string.IsNullOrEmpty(_sessionToken))
                {
                    InitToken();
                }
                return _sessionToken;
            }
        }

        static void InitToken()
        {
            sqlite_conn = DBHelper.CreateConnection();
            bool TableExists = DBHelper.CheckTableInDatabase(sqlite_conn);
            if (!TableExists)
                DBHelper.CreateTable(sqlite_conn);
        }
        public ContactInfoMaintainController() : base()
        {
            InitToken();
        }
        // GET: ContactInfoMaintain
        private static SQLiteConnection sqlite_conn;

        [HttpGet]
        [Route("api/ContactInfoMaintain/ListContact")]
        public ContactDetails GetContactInfoDetails()
        {
            DBHelper.InsertData(sqlite_conn, "");
            var result = new ContactDetails();
            try
            {
                string FirstName = string.Empty;
                string PhoneNumber = string.Empty;
                string Email = string.Empty;
                string LastName = string.Empty;
                string Status = string.Empty;

                dynamic ContactInfoDetails;
                result.InfoDetails = new List<ContactInfo>();

                SQLiteDataReader sqlite_datareader = DBHelper.ReadData(sqlite_conn);
                while (sqlite_datareader.Read())
                {
                    string myreader = sqlite_datareader.GetString(0);
                    Console.WriteLine(myreader);
                    FirstName = sqlite_datareader.GetString(0);
                    LastName = sqlite_datareader.GetString(1);
                    Email = sqlite_datareader.GetString(2);
                    PhoneNumber = sqlite_datareader.GetString(3);
                    Status = sqlite_datareader.GetString(4);

                    ContactInfoDetails = new ContactInfo();
                    ContactInfoDetails.FirstName = FirstName;
                    ContactInfoDetails.LastName = LastName;
                    ContactInfoDetails.Email = Email;
                    ContactInfoDetails.PhoneNumber = PhoneNumber;
                    ContactInfoDetails.Status = Status;

                    result.InfoDetails.Add(ContactInfoDetails);
                }
                return result;
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                return result = null;
            }
        }

        [HttpPost]
        [Route("api/ContactInfoMaintain/AddContact")]
        public string AddContactDetailsInfo([FromBody] ContactInfo contactDetails)
        {
            string result = string.Empty;
            try
            {
                result= Validator.ValidateEmail(contactDetails.Email);
                bool isNumberValid = Validator.ValidatePhoneNumber(contactDetails.PhoneNumber);
                if(!String.IsNullOrEmpty(result) && !isNumberValid)
                {
                    return "Email and Phone Number are not in correct format";
                }
                if(!String.IsNullOrEmpty(result))
                {
                    return result;
                }
                if(!isNumberValid)
                {
                    return "Phone Number is not valid";
                }
                lock (_object)
                {
                    string insertQuery = "INSERT INTO ContactInfoMaintain(FirstName, LastName, Email, PhoneNumber, Status) VALUES('" + contactDetails.FirstName + "','" + contactDetails.LastName + "','" + contactDetails.Email + "','" + contactDetails.PhoneNumber + "','Active');";
                    DBHelper.InsertData(sqlite_conn, insertQuery);
                    return "New contact detail added to ContactinfoMaintain ";

                }
            }
            catch (Exception ex)
            {
                result= "Incorrect data inserted";
            }
            return result;
        }
        [HttpDelete]
        [Route("api/ContactInfoMaintain/DeleteContact/{PhoneNumber}")]
        public string DeleteContact(string PhoneNumber)
        {
            string result = string.Empty;
            if (Validator.ValidatePhoneNumber(PhoneNumber))
            {
                SQLiteDataReader sqlite_datareader = DBHelper.ReadData(sqlite_conn);
                while (sqlite_datareader.Read())
                {
                    string IteratePhoneNumber = sqlite_datareader.GetString(3);
                    if (IteratePhoneNumber == PhoneNumber)
                    {
                        try
                        {
                            DBHelper.DeleteData(sqlite_conn, PhoneNumber);
                           return result = "Deleted contact detail:" + PhoneNumber;
                        }
                        catch (Exception ex)
                        {
                            result = "Enter correct PhoneNumber";
                        }
                    }
                    
                }
                return "No record found to delete for PhoneNumber";
            }
            else
            {
                return "Phone Number is not valid";
            }
            return result;
        }
        [HttpPut]
        [Route("api/ContactInfoMaintain/EditContact")]
        public string EditContactDetailsInfo([FromBody] ContactInfo contactDetails)
        {
            string result = string.Empty;
            if (String.IsNullOrEmpty(Validator.ValidateEmail(contactDetails.Email)))
            {
                SQLiteDataReader sqlite_datareader = DBHelper.ReadData(sqlite_conn);
                while (sqlite_datareader.Read())
                {
                    string IteratePhoneNumber = sqlite_datareader.GetString(3);
                    if (IteratePhoneNumber == contactDetails.PhoneNumber)
                    {

                        string query = "UPDATE ContactInfoMaintain SET FirstName = '" + contactDetails.FirstName + "',LastName = '" + contactDetails.LastName + "',Email = '" + contactDetails.Email + "' WHERE PhoneNumber = '" + IteratePhoneNumber + "'; ";
                        DBHelper.UpdateData(sqlite_conn, query);
                        return result = "Updated rows for PhoneNumber:" + IteratePhoneNumber;
                    }
                    else
                    {
                        result = "No match found to update, insert correct PhoneNumber";
                    }
                }
            }
            else
            {
                return result = "Email address is not valid";
            }
            return result;
        }

        [HttpGet]
        [Route("api/ContactInfoMaintain/ChangeStatus/{PhoneNumber}")]
        public string ChangeStatusDetails(string PhoneNumber)
        {
            string result = string.Empty;
            if (Validator.ValidatePhoneNumber(PhoneNumber))
            {
                SQLiteDataReader sqlite_datareader = DBHelper.ReadData(sqlite_conn);
                while (sqlite_datareader.Read())
                {
                    string IteratePhoneNumber = sqlite_datareader.GetString(3);
                    if (IteratePhoneNumber == PhoneNumber)
                    {

                        DBHelper.ChangeStatusOfData(sqlite_conn, PhoneNumber);
                       return "Status changed for PhoneNumber:" + PhoneNumber;
                    }
                }
                result = "No record found for PhoneNumber:" + PhoneNumber;
            }
            else
            {
                return "Phone number is not valid";
            }
            return result;
           
        }

        [HttpPut]
        [Route("api/ContactInfoMaintain/UpdateContactNumber")]
        public string UpdateContactDetails([FromBody] PhoneNumberInfo PhoneNumberDetails)
        {
            string result = string.Empty;
            if (Validator.ValidatePhoneNumber(PhoneNumberDetails.OldNumber) || Validator.ValidatePhoneNumber(PhoneNumberDetails.NewNumber))
            {
                SQLiteDataReader sqlite_datareader = DBHelper.ReadData(sqlite_conn);
                while (sqlite_datareader.Read())
                {
                    string IteratePhoneNumber = sqlite_datareader.GetString(3);
                    if (IteratePhoneNumber == PhoneNumberDetails.OldNumber)
                    {

                        string query = "UPDATE ContactInfoMaintain SET PhoneNumber = '" + PhoneNumberDetails.NewNumber + "' WHERE PhoneNumber = '" + PhoneNumberDetails.OldNumber + "'; ";
                        DBHelper.UpdateData(sqlite_conn, query);
                        return result = $"Updated PhoneNumber:{IteratePhoneNumber} with new number: {PhoneNumberDetails.NewNumber}";
                    }
                    else
                    {
                        result = "No match found to update, insert correct PhoneNumber";
                    }
                }
            }
            else
            {
                return "Phone Number is not valid";
            }
            return result;
        }
    }
}