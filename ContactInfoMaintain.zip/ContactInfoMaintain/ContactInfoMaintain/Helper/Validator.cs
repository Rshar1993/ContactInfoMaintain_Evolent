﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace ContactInfoMaintain.Helper
{
    public static class Validator
    {
        public static string ValidateEmail(string Email)
        {
            if (!Regex.IsMatch(Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.IgnoreCase))
            {
                return "Email id is not in correct format,Please enter valid Email Address";
            }
            return string.Empty;
        }
        public static bool ValidatePhoneNumber(string PhoneNumber)
        {
            bool value = PhoneNumber.All(char.IsDigit) && (PhoneNumber.Length == 10);
            return value;
        }
    }
}